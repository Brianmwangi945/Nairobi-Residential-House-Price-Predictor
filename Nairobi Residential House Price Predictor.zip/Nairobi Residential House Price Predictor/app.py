from flask import Flask, render_template, request
import pandas as pd
import joblib

app = Flask(__name__)

# Load the saved model pipeline
model = joblib.load("house_price_model.pkl")

# Load original dataset to extract dropdown options
df = pd.read_csv("Nairobi_House_Prices.csv")
locations = sorted(df["Location"].unique())
property_types = sorted(df["Type"].unique())

@app.route("/", methods=["GET"])
def home():
    return render_template("index.html", locations=locations, property_types=property_types)

@app.route("/predict", methods=["POST"])
def predict():
    try:
        # Retrieve form data
        input_data = {
            "Location": request.form["location"],
            "Type": request.form["type"],
            "Bedrooms": int(request.form["bedrooms"]),
            "Bathrooms": int(request.form["bathrooms"]),
            "Size (sqm)": float(request.form["size (sqm)"]),
            "Garage": request.form["garage"],
            "Servant Quarter": request.form["servant quarter"],
            "Year Built": int(request.form["year built"]),
            "Condition": request.form["condition"]
        }

        # Convert to DataFrame
        input_df = pd.DataFrame([input_data])

        # Make prediction
        prediction = model.predict(input_df)[0]
        prediction_text = f"Estimated House Price: KSh {int(prediction):,}"

        return render_template("index.html", prediction_text=prediction_text,
                               locations=locations, property_types=property_types)

    except Exception as e:
        return f"❌ An error occurred during prediction: {str(e)}"

if __name__ == "__main__":
    app.run(debug=True)
